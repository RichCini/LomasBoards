# CP/M-86 Diskette Image Analysis & Repair Report
File: `ccpm86_d1orig.img` — 327,680 bytes (320KB, 40 tracks × 2 sides × 8 sectors × 512 bytes)

## 1. Geometry / filesystem identified
- Boot code at sector 0 relocates itself and jumps to `2820:0000` — a standard DRI CP/M-86
  IPL, and it is intact (no damage found in sectors 0–15).
- Reserved area: 2 tracks (sectors 0–15).
- Directory: exactly 1 block, 64 entries, starting at sector 16 (offset `0x2000`).
- Block size: 2048 bytes (4 sectors/block), 1-byte allocation pointers, 156 total blocks (0–155).
- Embedded strings confirm the OS: **Concurrent CP/M-86 2.0** (Digital Research, 03/31/83).

## 2. Corruption found

### a) Directory block damage (sector 16, entries 0–15)
The **first 14 directory entries** (bytes `0x2000`–`0x21BF`) do not contain valid CP/M
directory data — they contain a foreign binary table (structured 16-bit values, not
printable filenames). Entry 14 is a mangled fragment (a stray NUL byte followed by
readable text `MXLoad `), and entry 15 is all-zero (a valid CP/M directory uses `0xE5`
for "empty/deleted", never `0x00`). None of this is valid per the CP/M directory format,
and a real CP/M would either mis-list bogus files (several byte-0 "user numbers" exceed
the legal range 0–31) or become confused walking the allocation lists.

Entries 16–63 (sector 17 onward) are well-formed: 12 valid files followed by 52 correctly
empty (`0xE5`) entries.

**Consequence:** blocks 1–90 and 150–155 (96 of 156 data blocks — the majority of the
disk's file content) are *orphaned*: real data still sits on the disk, but no surviving
directory entry references it, so a stock CP/M would treat all of that space as free
and could overwrite it on the next file write.

Three of the surviving files (`SYSTAT.CMD`, `ASM86.CMD`, `SYSTAT1.CMD`) have `EX=1`,
meaning their *first* extent (≈16KB each, the missing directory entries) is exactly
the piece that was destroyed — these three files are structurally incomplete as they
stand.

### b) Physically unreadable sectors
23 sectors (11,776 bytes, ~3.6% of the disk), all inside the orphaned region, are filled
with a uniform, non-standard byte `0x44` — unlike CP/M's own "unused" filler (`0xE5`) or
ordinary zero-padding, this is consistent with sectors the original drive could not read
and that got replaced with a fixed pattern at some point:

| Block(s) | Sectors |
|---|---|
| 40 (tail) | 179 |
| 41 | 180–183 |
| 44 | 192–195 |
| 45 | 196–199 |
| 48 | 208–211 |
| 49 | 212–215 |
| 52 (head) | 224–225 |

This portion of the lost data is not recoverable from this image.

### c) Everything else
The 12 surviving files (`VCMODE`, `ED`, `TYPE`, `PIP`, `SET`, `DATE`, `CHSET`, `FORMAT`,
`MFORMAT` complete; `SYSTAT`, `ASM86`, `SYSTAT1` — extent 1 only) have contiguous,
non-overlapping allocation with no other inconsistencies.

## 3. Repair performed
`ccpm86_d1_repaired.img`: the 512 bytes of sector 16 (directory entries 0–15) were
rewritten as standard empty entries (`0xE5` × 512), matching the convention CP/M itself
uses for unused directory slots. This is the only change made to the image (verified via
byte diff). Nothing else was touched, so:
- The boot loader and all 12 intact files are byte-for-byte unchanged and now load under
  a normal CP/M/emulator without the invalid entries confusing directory routines.
- The orphaned data blocks are left in place on disk (not wiped) in case further manual
  recovery is wanted later, but the filesystem no longer claims to know what they are.

## 4. Recovered orphan data
Since the original filenames/extents for blocks 1–90 and 150–155 cannot be reconstructed
(the metadata itself is gone, not just misread), I did not fabricate directory entries for
them. Instead the readable portions (everything except the 23 bad sectors above) are
extracted as six raw chunks for manual inspection/archival:

| File | Sectors | Bytes | Notable embedded strings |
|---|---|---|---|
| orphan_01 | 20–178 | 81,408 | SYSTAT help/command text, FORMAT prompts, CHSET help |
| orphan_02 | 184–191 | 4,096 | (no readable strings — likely compiled code) |
| orphan_03 | 200–207 | 4,096 | DATE.CMD prompts ("Enter today's date...") |
| orphan_04 | 216–223 | 4,096 | SET.CMD help text, CCP/M-86 2.0 copyright |
| orphan_05 | 226–379 | 78,848 | ASM86 assembler tables, DDT86 1.2 copyright, PIP 3.1 copyright, SET 2.1 copyright |
| orphan_06 | 616–639 | 12,288 | More CCP/M-86 file-utility strings (rename/password/BDOS errors) |

These strings line up with the three incomplete files identified above (`SYSTAT`,
`ASM86`, `SYSTAT1` all reference DDT86/PIP/SET-era Concurrent CP/M-86 2.0 text), so it's
likely their missing first extents — and possibly additional files/user areas that
existed on the original disk — live inside these chunks, just no longer addressable by
filename.

## 5. Bottom line
- Boot sector: OK.
- 12 of the original files: fully intact and verified consistent, now cleanly mountable.
- 3 files (SYSTAT, ASM86, SYSTAT1): missing their first extent; raw candidate data
  recovered separately but not reattached automatically (would require manual/expert
  reconstruction to confirm exact boundaries).
- ~11.5KB (23 sectors) of the disk is permanently unreadable in this image.
- ~150KB of additional data of unknown original filename structure was recovered as raw
  blocks rather than guessed at.
